const express = require('express');
const cors = require('cors');
const fs = require('fs');
const path = require('path');
const bodyParser = require('body-parser');
const session = require('express-session');

const app = express();
const port = 3000;

// Utilisateurs stockés en mémoire (pour l'exemple)
let users = {};
let words = []; // Global variable to store all words
let wordOfDay; // Global variable to store the word of the day

app.use(cors());
app.use(express.static('public'));
app.use(bodyParser.urlencoded({ extended: true }));
app.use(session({
    secret: 'secretMotus',
    resave: false,
    saveUninitialized: true,
    cookie: { secure: false }
}));

// Function to load words and initialize wordOfDay
function loadWords() {
    const data = fs.readFileSync(path.join(__dirname, 'data', 'liste_francais_utf8.txt'), 'utf8');
    words = data.split('\n');
    changeWord(); // Initialize wordOfDay
}

// Function to change the word of the day
function changeWord() {
    wordOfDay = words[Math.floor(Math.random() * words.length)].trim();
}

app.get('/word', (req, res) => {
    res.send(wordOfDay);
});

app.get('/new-word', (req, res) => {
    changeWord();
    res.send(wordOfDay);
});
// Middleware
app.use(express.static('public')); // Serveur de fichiers statiques
app.use(bodyParser.urlencoded({ extended: true }));
app.use(session({
    secret: 'secretMotus',
    resave: false,
    saveUninitialized: true,
    cookie: { secure: false } // Sécurité désactivée pour l'exemple
}));

// Authentification
app.post('/login', (req, res) => {
    const { login, password } = req.body;
    if (users[login] && users[login] === password) {
        req.session.user = login;
        res.redirect('/');
    } else {
        res.send('Identifiant ou mot de passe incorrect.');
    }
});

app.post('/register', (req, res) => {
    const { login, password, password2 } = req.body;
    if (password !== password2) {
        return res.send('Les mots de passe ne correspondent pas.');
    }
    if (users[login]) {
        return res.send('Cet utilisateur existe déjà.');
    }
    users[login] = password;
    res.redirect('/login.html');
});

app.get('/current-user', (req, res) => {
    if (req.session.user) {
        res.json({ user: req.session.user });
    } else {
        res.status(401).send('Non authentifié.');
    }
});

// Redirection vers login si non authentifié
app.use((req, res, next) => {
    if (req.session.user || req.path === '/login.html' || req.path.includes('/register') || req.path.includes('/login')) {
        next();
    } else {
        res.redirect("/login.html");
    }
});
app.listen(port, () => {
    console.log(`Server running on http://localhost:${port}`);
    loadWords(); // Load words when the server starts
});
